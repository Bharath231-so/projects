package com.example.leave_management_project.service;

import java.util.List;

import com.example.leave_management_project.entity.Employee;

public interface EmployeeService {

    Employee registerEmployee(Employee employee);

    Employee findByEmail(String email);

    List<Employee> getAllEmployees();

    Employee getEmployeeById(Long id);

    void deleteEmployee(Long id);
}