package com.example.leave_management_project.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.leave_management_project.entity.LeaveRequest;
import com.example.leave_management_project.repository.LeaveRequestRepository;
import com.example.leave_management_project.service.ManagerService;

@Service
public class ManagerServiceImpl implements ManagerService {

    @Autowired
    private LeaveRequestRepository leaveRepository;

    @Override
    public List<LeaveRequest> getPendingLeaves() {
        return leaveRepository.findByStatus("PENDING");
    }

    @Override
    public LeaveRequest approveLeave(Long leaveId) {

        LeaveRequest leave =
                leaveRepository.findById(leaveId).orElse(null);

        if (leave != null) {
            leave.setStatus("APPROVED");
            return leaveRepository.save(leave);
        }

        return null;
    }

    @Override
    public LeaveRequest rejectLeave(Long leaveId) {

        LeaveRequest leave =
                leaveRepository.findById(leaveId).orElse(null);

        if (leave != null) {
            leave.setStatus("REJECTED");
            return leaveRepository.save(leave);
        }

        return null;
    }
}