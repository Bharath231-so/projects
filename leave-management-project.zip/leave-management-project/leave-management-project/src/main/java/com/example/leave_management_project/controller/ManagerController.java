package com.example.leave_management_project.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.leave_management_project.entity.Employee;
import com.example.leave_management_project.repository.EmployeeRepository;
import com.example.leave_management_project.service.LeaveService;
import com.example.leave_management_project.service.ManagerService;

@Controller
public class ManagerController {

    @Autowired
    private ManagerService managerService;
    
    @Autowired
    private LeaveService leaveService;
    
    @Autowired
    private EmployeeRepository employeeRepository;
    

    @GetMapping("/manager/dashboard")
    public String managerDashboard(Model model, Principal principal) {

        model.addAttribute(
                "pendingLeaves",
                managerService.getPendingLeaves());

        Employee manager =
                employeeRepository.findByEmail(principal.getName())
                .orElseThrow();

        List<Employee> teamMembers =
                employeeRepository.findByManager(manager);

        model.addAttribute("teamMembers", teamMembers);

        return "manager/dashboard";
    }
    
    @GetMapping("/manager/approve/{id}")
    public String approve(@PathVariable Long id) {

        leaveService.approveLeave(id);

        return "redirect:/manager/dashboard";
    }
    @GetMapping("/manager/reject/{id}")
    public String reject(@PathVariable Long id) {

        leaveService.rejectLeave(id);

        return "redirect:/manager/dashboard";
    }
    
    
}