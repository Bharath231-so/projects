package com.example.leave_management_project.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.leave_management_project.entity.Employee;
import com.example.leave_management_project.entity.Role;

import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    Optional<Employee> findByEmail(String email);

    boolean existsByEmail(String email);
    
    List<Employee> findByRole(Role role);
    
    List<Employee> findByManager(Employee manager);
    
    long countByRole(Role role);
}