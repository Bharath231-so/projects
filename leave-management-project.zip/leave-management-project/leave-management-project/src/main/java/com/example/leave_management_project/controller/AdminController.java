package com.example.leave_management_project.controller;

import java.util.List;

import com.example.leave_management_project.entity.Role;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.leave_management_project.entity.Employee;
import com.example.leave_management_project.repository.EmployeeRepository;
import com.example.leave_management_project.service.AdminService;
import com.example.leave_management_project.entity.*;

@Controller
public class AdminController {

    @Autowired
    private AdminService adminService;

    @Autowired
    private EmployeeRepository  employeeRepository;
    
    
    @GetMapping("/admin/dashboard")
    public String dashboard(Model model) {

        model.addAttribute("totalEmployees",
                adminService.getAllEmployees().size());

        model.addAttribute("totalLeaves",
                adminService.getAllLeaves().size());
        
        model.addAttribute("leaves", adminService.getAllLeaves());

        long pending = adminService.getAllLeaves().stream()
                .filter(l -> l.getStatus().equals("PENDING"))
                .count();

        long approved = adminService.getAllLeaves().stream()
                .filter(l -> l.getStatus().equals("APPROVED"))
                .count();

        long rejected = adminService.getAllLeaves().stream()
                .filter(l -> l.getStatus().equals("REJECTED"))
                .count();

        model.addAttribute("pending", pending);
        model.addAttribute("approved", approved);
        model.addAttribute("rejected", rejected);

        return "admin/dashboard";
    }
    
    @GetMapping("/admin/employees")
    public String employees(Model model) {
        model.addAttribute("employees", adminService.getAllEmployees());
        return "admin/employees";
    }

    @GetMapping("/admin/managers")
    public String managers(Model model) {
        model.addAttribute("managers", adminService.getAllManagers());
        return "admin/managers";
    }

    @GetMapping("/admin/leaves")
    public String leaves(Model model) {
        model.addAttribute("leaves", adminService.getAllLeaves());
        return "admin/all-leaves";
    }
    @GetMapping("/admin/assign-manager/{id}")
    public String assignManagerPage(@PathVariable Long id, Model model) {

       
		Employee employee = employeeRepository.findById(id).orElseThrow();

        List<Employee> managers =
                employeeRepository.findByRole(Role.MANAGER);

        model.addAttribute("employee", employee);
        model.addAttribute("managers", managers);

        return "admin/assign-manager";
    }

    @PostMapping("/admin/assign-manager")
    public String assignManager(@RequestParam Long employeeId,
                                @RequestParam Long managerId) {

        Employee employee =
                employeeRepository.findById(employeeId).orElseThrow();

        Employee manager =
                employeeRepository.findById(managerId).orElseThrow();

        employee.setManager(manager);

        employeeRepository.save(employee);

        return "redirect:/admin/employees";
    }
    
   
}