package com.example.leave_management_project.entity;

public enum Role {

    ADMIN,
    MANAGER,
    EMPLOYEE

}
