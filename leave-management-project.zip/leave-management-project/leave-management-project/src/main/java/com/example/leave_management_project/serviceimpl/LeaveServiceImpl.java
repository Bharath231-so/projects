package com.example.leave_management_project.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.leave_management_project.entity.Employee;
import com.example.leave_management_project.entity.LeaveRequest;
import com.example.leave_management_project.repository.EmployeeRepository;
import com.example.leave_management_project.repository.LeaveRequestRepository;
import com.example.leave_management_project.service.LeaveService;

@Service
public class LeaveServiceImpl implements LeaveService {

    @Autowired
    private LeaveRequestRepository leaveRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public LeaveRequest applyLeave(LeaveRequest leaveRequest) {
        leaveRequest.setStatus("PENDING");
        return leaveRepository.save(leaveRequest);
    }

    @Override
    public List<LeaveRequest> getAllLeaves() {
        return leaveRepository.findAll();
    }

    @Override
    public List<LeaveRequest> getPendingLeaves() {
        return leaveRepository.findByStatus("PENDING");
    }

    @Override
    public LeaveRequest approveLeave(Long leaveId) {

        LeaveRequest leave = leaveRepository.findById(leaveId).orElse(null);

        if (leave != null) {

            leave.setStatus("APPROVED");

            Employee employee = leave.getEmployee();

            employee.setLeaveBalance(
                employee.getLeaveBalance() - leave.getNumberOfDays());

            employeeRepository.save(employee);

            return leaveRepository.save(leave);
        }

        return null;
    }

    @Override
    public LeaveRequest rejectLeave(Long leaveId) {

        LeaveRequest leave = leaveRepository.findById(leaveId).orElse(null);

        if (leave != null) {
            leave.setStatus("REJECTED");
            return leaveRepository.save(leave);
        }

        return null;
    }

    @Override
    public LeaveRequest getLeaveById(Long leaveId) {
        return leaveRepository.findById(leaveId).orElse(null);
    }
}