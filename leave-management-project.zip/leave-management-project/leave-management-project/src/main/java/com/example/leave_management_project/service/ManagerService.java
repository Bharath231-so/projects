package com.example.leave_management_project.service;

import java.util.List;

import com.example.leave_management_project.entity.LeaveRequest;

public interface ManagerService {

    List<LeaveRequest> getPendingLeaves();

    LeaveRequest approveLeave(Long leaveId);

    LeaveRequest rejectLeave(Long leaveId);
}