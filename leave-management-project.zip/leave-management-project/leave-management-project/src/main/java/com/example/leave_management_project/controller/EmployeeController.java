package com.example.leave_management_project.controller;

import java.security.Principal;
import java.util.List;

import org.apache.tomcat.util.net.openssl.ciphers.Authentication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.leave_management_project.entity.Employee;
import com.example.leave_management_project.entity.LeaveRequest;
import com.example.leave_management_project.service.EmployeeService;
//import com.example.leave_management_project.serviceimpl.LeaveServiceImpl;
import com.example.leave_management_project.service.*;

@Controller
public class EmployeeController {
	@Autowired
	private LeaveService leaveService;

	
	
	
	
	

   @Autowired
    private EmployeeService employeeService;
   
   @GetMapping("/employee/apply")
   public String applyPage() {
       return "employee/apply-leave";
   }
   
   @PostMapping("/employee/apply")
   public String applyLeave(@ModelAttribute LeaveRequest leave,
                            Principal principal) {

       Employee emp = employeeService.findByEmail(principal.getName());

       leave.setEmployee(emp);
       leave.setStatus("PENDING");

       leaveService.applyLeave(leave);

       return "redirect:/employee/dashboard";
   }
   

   @GetMapping("/employee/dashboard")
   public String employeeDashboard(Model model, Principal principal) {

       Employee employee =
               employeeService.findByEmail(principal.getName());

       List<LeaveRequest> leaves =
               leaveService.getAllLeaves();

       long pending =
               leaves.stream()
                     .filter(l -> l.getEmployee().getId().equals(employee.getId()))
                     .filter(l -> l.getStatus().equals("PENDING"))
                     .count();

       long approved =
               leaves.stream()
                     .filter(l -> l.getEmployee().getId().equals(employee.getId()))
                     .filter(l -> l.getStatus().equals("APPROVED"))
                     .count();

       long rejected =
               leaves.stream()
                     .filter(l -> l.getEmployee().getId().equals(employee.getId()))
                     .filter(l -> l.getStatus().equals("REJECTED"))
                     .count();

       model.addAttribute("employee", employee);
       model.addAttribute("pending", pending);
       model.addAttribute("approved", approved);
       model.addAttribute("rejected", rejected);
       
       model.addAttribute("leaves",leaveService.getAllLeaves().stream().filter(l ->l.getEmployee().getId().equals(employee.getId())).toList() );

       return "employee/dashboard";
   } 
    
    @GetMapping("/employee/history")
    public String history(Model model, Principal principal) {

        Employee emp = employeeService.findByEmail(principal.getName());

        model.addAttribute(
            "leaves",
            leaveService.getAllLeaves()
                .stream()
                .filter(l -> l.getEmployee().getId().equals(emp.getId()))
                .toList()
        );

        return "employee/leave-history";
    }
    @GetMapping("/employee/profile")
    public String profile(Model model,Principal principal) {

        Employee employee =
                employeeService.findByEmail(principal.getName());
                

        model.addAttribute("employee", employee);

        return "employee/profile";
    }
    
}