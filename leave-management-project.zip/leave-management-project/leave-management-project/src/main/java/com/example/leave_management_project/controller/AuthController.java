package com.example.leave_management_project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.leave_management_project.entity.Employee;
import com.example.leave_management_project.entity.Role;
import com.example.leave_management_project.repository.EmployeeRepository;

@Controller
public class AuthController {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private AuthenticationManager authenticationManager;

    // LOGIN PAGE
    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    // REGISTER PAGE
    @GetMapping("/register")
    public String registerPage(Model model) {
        model.addAttribute("employee", new Employee());
        return "register";
    }

    // REGISTER POST
    @PostMapping("/register")
    public String register(@ModelAttribute Employee employee) {

        employee.setRole(Role.EMPLOYEE);

        // Encrypt password
        employee.setPassword(passwordEncoder.encode(employee.getPassword()));

        employeeRepository.save(employee);

        return "redirect:/login?success";
    }

    // DEFAULT REDIRECT AFTER LOGIN
    @GetMapping("/default")
    public String defaultAfterLogin(Authentication auth) {

        String role = auth.getAuthorities().toString();

        if (role.contains("ADMIN")) {
            return "redirect:/admin/dashboard";
        }
        else if (role.contains("MANAGER")) {
            return "redirect:/manager/dashboard";
        }
        else {
            return "redirect:/employee/dashboard";
        }
    }
}