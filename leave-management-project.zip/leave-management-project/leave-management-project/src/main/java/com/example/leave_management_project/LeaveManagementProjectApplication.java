package com.example.leave_management_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LeaveManagementProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(LeaveManagementProjectApplication.class, args);
	}

}
