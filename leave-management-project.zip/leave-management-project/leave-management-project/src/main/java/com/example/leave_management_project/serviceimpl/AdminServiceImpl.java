package com.example.leave_management_project.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.leave_management_project.entity.Employee;
import com.example.leave_management_project.entity.LeaveRequest;
import com.example.leave_management_project.entity.Role;
import com.example.leave_management_project.repository.EmployeeRepository;
import com.example.leave_management_project.repository.LeaveRequestRepository;
import com.example.leave_management_project.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private LeaveRequestRepository leaveRepository;

    @Override
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    @Override
    public List<LeaveRequest> getAllLeaves() {
        return leaveRepository.findAll();
    }

    @Override
    public void deleteEmployee(Long id) {
        employeeRepository.deleteById(id);
    }
    
   

    @Override
    public List<Employee> getAllManagers() {
        return employeeRepository.findByRole(Role.MANAGER);
    }

   
}