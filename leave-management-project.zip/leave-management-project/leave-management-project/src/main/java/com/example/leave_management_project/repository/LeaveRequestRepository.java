package com.example.leave_management_project.repository;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.leave_management_project.entity.Employee;
import com.example.leave_management_project.entity.LeaveRequest;

@Repository
public interface LeaveRequestRepository extends JpaRepository<LeaveRequest, Long> {

   
    List<LeaveRequest> findByEmployee(Employee employee);

 
    List<LeaveRequest> findByStatus(String status);


    long countByStatus(String status);

   
    long countByEmployeeAndStatus(Employee employee, String status);

  
    List<LeaveRequest> findAllByOrderByAppliedDateDesc();

}
