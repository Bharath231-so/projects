package com.example.leave_management_project.service;

import java.util.List;

import com.example.leave_management_project.entity.LeaveRequest;

public interface LeaveService {

    LeaveRequest applyLeave(LeaveRequest leaveRequest);

    List<LeaveRequest> getAllLeaves();

    List<LeaveRequest> getPendingLeaves();

    LeaveRequest approveLeave(Long leaveId);

    LeaveRequest rejectLeave(Long leaveId);

    LeaveRequest getLeaveById(Long leaveId);
}