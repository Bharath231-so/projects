package com.example.leave_management_project.service;

import java.util.List;

import com.example.leave_management_project.entity.Employee;
import com.example.leave_management_project.entity.LeaveRequest;

public interface AdminService {

    List<Employee> getAllEmployees();

    List<LeaveRequest> getAllLeaves();
    
   

    List<Employee> getAllManagers();


    void deleteEmployee(Long id);
}