package com.example.leave_management_project.config;

import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

import com.example.leave_management_project.entity.Employee;
import com.example.leave_management_project.repository.EmployeeRepository;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import java.util.Collections;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {

        Employee emp = employeeRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
        System.out.println("Login email = "+ email);

        return new org.springframework.security.core.userdetails.User(
                emp.getEmail(),
                emp.getPassword(),
                Collections.singleton(new SimpleGrantedAuthority( emp.getRole().name()))
        );
    }
}