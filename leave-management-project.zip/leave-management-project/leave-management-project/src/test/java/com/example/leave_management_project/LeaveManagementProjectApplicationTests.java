package com.example.leave_management_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeaveManagementProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
