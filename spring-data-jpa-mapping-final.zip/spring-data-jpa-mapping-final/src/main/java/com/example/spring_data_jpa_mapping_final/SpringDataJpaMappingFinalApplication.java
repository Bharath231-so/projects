package com.example.spring_data_jpa_mapping_final;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpaMappingFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaMappingFinalApplication.class, args);
	}

}
