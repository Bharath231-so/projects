package com.example.spring_data_jpa_mapping_final;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpaMappingFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
