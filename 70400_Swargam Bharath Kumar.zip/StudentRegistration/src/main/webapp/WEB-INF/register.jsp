<form action="save" method="post">

Id:
<input type="text" name="id"/><br><br>
Name:
<input type="text" name="name"/><br><br>
Course:
<input type="text" name="course"/><br><br>
Fee:
<input type="text" name="fee"/><br><br>
<input type="submit" value="Register"/>
</form>