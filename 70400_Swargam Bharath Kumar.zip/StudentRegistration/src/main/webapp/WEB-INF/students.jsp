<table border="1">
<tr>
<th>ID</th>
<th>Name</th>
<th>Course</th>
<th>Fee</th>
</tr>
<c:forEach items="${student}" var="s">
<tr>
<td>${s.id}</td>
<td>${s.name}</td>
<td>${s.course}</td>
<td>${s.fee}</td>
</tr>
</c:forEach>
</table>