package com.model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="student")

public class Student {
	@Id
	private int id;
	private String name;
	private String course;
	private String fee;
	public Student() {
		public Student(int id,String name,String course,String fee) {
			this.id=id;
			this.fee=fee;
			this.course=course;
			this.name=name;
		}
	}

}
