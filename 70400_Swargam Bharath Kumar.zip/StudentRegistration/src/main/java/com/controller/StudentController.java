package com.controller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import com.service.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.beans.factory.annotation.Autowired;



public class StudentController {
	private StudentService service;
	@Autowired
	public StudentController(StudentService service) {
		this.service=service;
		
	}
	@GetMapping("/")
	public String registerPage() {
		return "register";
	}
	@PostMapping("/save")
	public String save(Student student) {
		service.saveStudent(student);
		return "redirect:/students";
	}
	@GetMapping("/students")
	public String students(Model model) {
		model.addAttributes("students",service.getStudents());
		return "students";
	}
}
