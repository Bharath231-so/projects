package com.dao;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.model.*;

public class StudentDAO {
	private SessionFactory sessionFactory;
	@Autowired
	public StudentDAO(SessionFactory sessionFactory) {
		this.sessionFactory=sessionFactory;
	}
	public void save(Student student) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(student);
		tx.commit();
		session.close();
	}
	public List<Student>getAllStudents(){
		Session session=sessionFactory.opensession();
		List<Student>list=session.createQuery("from student",Student.class).list();
		session.close();
		return list;
	}
}
