package com.config;

public class AppConfig {
	@Bean
	public SessionFactory sessionFactory() {
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		cfg.addAnnotatedClass(Student.class);
		return cfg.buildSessionFactory();
	}

}
