package com.service;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.transaction.annotation.Transactional;

import com.model.Student;

public class StudentService {
	private StudentDAO studentDao;
	@Autowired
	public StudentService(StudentDao studentDao) {
		this.studentDao=studentDao;
		
	}
	public void saveStudent(Student student) {
		studentDao.save(student);
	}
	public List<Student>getStudents(){
		return StudentDaO.getAllStudents();
	}

}
