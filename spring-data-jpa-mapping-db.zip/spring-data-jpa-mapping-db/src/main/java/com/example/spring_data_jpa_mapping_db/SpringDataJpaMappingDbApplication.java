package com.example.spring_data_jpa_mapping_db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpaMappingDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaMappingDbApplication.class, args);
	}

}
