package com.example.spring_data_jpa_mapping_db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpaMappingDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
