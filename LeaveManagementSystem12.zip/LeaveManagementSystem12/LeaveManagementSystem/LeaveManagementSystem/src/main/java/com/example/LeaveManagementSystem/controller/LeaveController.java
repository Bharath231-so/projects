package com.example.LeaveManagementSystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.LeaveManagementSystem.entity.LeaveRequest;
import com.example.LeaveManagementSystem.entity.Employee;
import com.example.LeaveManagementSystem.service.LeaveService;
import jakarta.servlet.http.HttpSession;

@Controller
public class LeaveController {

    @Autowired
    private LeaveService leaveService;

    @GetMapping("/applyLeave")
    public String applyLeavePage(HttpSession session) {
        Employee employee = (Employee) session.getAttribute("loggedInEmployee");
        if (employee == null) {
            return "redirect:/login";
        }
        return "apply-leave";
    }

    @PostMapping("/saveLeave")
    public String saveLeave(
            LeaveRequest leaveRequest,
            HttpSession session) {
        Employee employee = (Employee) session.getAttribute("loggedInEmployee");
        if (employee == null) {
            return "redirect:/login";
        }
        leaveRequest.setEmployee(employee);
        leaveService.applyLeave(leaveRequest);

        return "redirect:/leaveHistory";
    }

    @GetMapping("/leaveHistory")
    public String leaveHistory(HttpSession session, Model model) {
        Employee employee = (Employee) session.getAttribute("loggedInEmployee");
        if (employee == null) {
            return "redirect:/login";
        }
        model.addAttribute("leaves",
                leaveService.getLeavesByEmployee(employee));

        return "leave-history";
    }

    @GetMapping("/leave/{id}")
    public String getLeaveById(
            @PathVariable Long id,
            HttpSession session,
            Model model) {
        Employee employee = (Employee) session.getAttribute("loggedInEmployee");
        if (employee == null) {
            return "redirect:/login";
        }
        LeaveRequest leave = leaveService.getLeaveById(id);
        if (leave == null || leave.getEmployee() == null || !leave.getEmployee().getId().equals(employee.getId())) {
            return "redirect:/leaveHistory";
        }
        model.addAttribute("leave", leave);

        return "leave-history";
    }

    @GetMapping("/deleteLeave/{id}")
    public String deleteLeave(
            @PathVariable Long id,
            HttpSession session) {
        Employee employee = (Employee) session.getAttribute("loggedInEmployee");
        if (employee == null) {
            return "redirect:/login";
        }
        LeaveRequest leave = leaveService.getLeaveById(id);
        if (leave != null && leave.getEmployee() != null && leave.getEmployee().getId().equals(employee.getId())) {
            leaveService.deleteLeave(id);
        }

        return "redirect:/leaveHistory";
    }
}