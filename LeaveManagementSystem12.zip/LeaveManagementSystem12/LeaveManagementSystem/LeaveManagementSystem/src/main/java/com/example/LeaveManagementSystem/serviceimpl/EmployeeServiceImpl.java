package com.example.LeaveManagementSystem.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.LeaveManagementSystem.entity.Employee;
import com.example.LeaveManagementSystem.repository.EmployeeRepository;
import com.example.LeaveManagementSystem.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public Employee registerEmployee(Employee employee) {
        // Set default leave balance for newly registered employee
        employee.setTotalLeaveBalance(12);
        employee.setUsedLeaves(0);
        employee.setRemainingLeaves(12);

        return employeeRepository.save(employee);
    }

    @Override
    public Employee getEmployeeById(Long id) {
        return employeeRepository.findById(id).orElse(null);
    }

    @Override
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    @Override
    public Employee updateEmployee(Long id, Employee employee) {

        Employee emp = employeeRepository.findById(id).orElse(null);

        if (emp != null) {
            emp.setName(employee.getName());
            emp.setEmail(employee.getEmail());
            emp.setDepartment(employee.getDepartment());
            emp.setRole(employee.getRole());

            // update leave balances only if values are passed
            if (employee.getTotalLeaveBalance() != null) {
                emp.setTotalLeaveBalance(employee.getTotalLeaveBalance());
            }

            if (employee.getUsedLeaves() != null) {
                emp.setUsedLeaves(employee.getUsedLeaves());
            }

            if (employee.getRemainingLeaves() != null) {
                emp.setRemainingLeaves(employee.getRemainingLeaves());
            }

            return employeeRepository.save(emp);
        }

        return null;
    }

    @Override
    public void deleteEmployee(Long id) {
        employeeRepository.deleteById(id);
    }

    @Override
    public Employee login(String email, String password) {
        Employee employee = employeeRepository.findByEmail(email);

        if (employee != null && employee.getPassword().equals(password)) {
            return employee;
        }

        return null;
    }
}