package com.example.LeaveManagementSystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.LeaveManagementSystem.entity.Employee;
import com.example.LeaveManagementSystem.service.EmployeeService;
import jakarta.servlet.http.HttpSession;

@Controller
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @PostMapping("/registerEmployee")
    public String registerEmployee(Employee employee) {

        employeeService.registerEmployee(employee);

        return "login";
    }

    @PostMapping("/loginEmployee")
    public String loginEmployee(
            @RequestParam String email,
            @RequestParam String password,
            HttpSession session,
            Model model) {

        Employee employee =
                employeeService.login(email, password);

        if (employee != null) {
            session.setAttribute("loggedInEmployee", employee);
            return "redirect:/dashboard";
        }

        model.addAttribute("error",
                "Invalid Email or Password");

        return "login";
    }

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        Employee sessionEmployee = (Employee) session.getAttribute("loggedInEmployee");

        if (sessionEmployee == null) {
            return "redirect:/login";
        }

        Employee employee = employeeService.getEmployeeById(sessionEmployee.getId());

        session.setAttribute("loggedInEmployee", employee);
        model.addAttribute("employee", employee);

        return "dashboard";
    }
    @GetMapping("/profile")
    public String profile(HttpSession session, Model model) {
        Employee sessionEmployee = (Employee) session.getAttribute("loggedInEmployee");

        if (sessionEmployee == null) {
            return "redirect:/login";
        }

        Employee employee = employeeService.getEmployeeById(sessionEmployee.getId());

        session.setAttribute("loggedInEmployee", employee);
        model.addAttribute("employee", employee);

        return "profile";
    }
    @GetMapping("/employees")
    public String getEmployees(HttpSession session, Model model) {
        Employee employee = (Employee) session.getAttribute("loggedInEmployee");
        if (employee == null || !"Admin".equalsIgnoreCase(employee.getRole())) {
            return "redirect:/login";
        }
        model.addAttribute("employees",
                employeeService.getAllEmployees());
        return "manage-employees";
    }

    @GetMapping("/deleteEmployee/{id}")
    public String deleteEmployee(
            @PathVariable Long id,
            HttpSession session) {
        Employee employee = (Employee) session.getAttribute("loggedInEmployee");
        if (employee == null || !"Admin".equalsIgnoreCase(employee.getRole())) {
            return "redirect:/login";
        }
        employeeService.deleteEmployee(id);
        return "redirect:/employees";
    }
}