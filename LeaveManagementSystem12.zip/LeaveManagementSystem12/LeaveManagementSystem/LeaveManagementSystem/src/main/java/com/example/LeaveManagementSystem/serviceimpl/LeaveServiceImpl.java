package com.example.LeaveManagementSystem.serviceimpl;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.LeaveManagementSystem.entity.Employee;
import com.example.LeaveManagementSystem.entity.LeaveRequest;
import com.example.LeaveManagementSystem.repository.LeaveRepository;
import com.example.LeaveManagementSystem.service.LeaveService;

@Service
public class LeaveServiceImpl implements LeaveService {

    @Autowired
    private LeaveRepository leaveRepository;

    @Override
    public LeaveRequest applyLeave(LeaveRequest leave) {

        // default status
        leave.setStatus("PENDING");

        // set applied date
        leave.setAppliedOn(LocalDate.now());

        // calculate leave days
        if (leave.getStartDate() != null && leave.getEndDate() != null) {
            long days = ChronoUnit.DAYS.between(leave.getStartDate(), leave.getEndDate()) + 1;
            leave.setAppliedDays((int) days);
        } else {
            leave.setAppliedDays(0);
        }

        return leaveRepository.save(leave);
    }

    @Override
    public List<LeaveRequest> getAllLeaves() {
        return leaveRepository.findAll();
    }

    @Override
    public LeaveRequest getLeaveById(Long id) {
        return leaveRepository.findById(id).orElse(null);
    }

    @Override
    public void deleteLeave(Long id) {
        leaveRepository.deleteById(id);
    }

    @Override
    public List<LeaveRequest> getLeavesByEmployee(Employee employee) {
        return leaveRepository.findByEmployee(employee);
    }
}