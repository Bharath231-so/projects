package com.example.LeaveManagementSystem.service;

import java.util.List;
import com.example.LeaveManagementSystem.entity.Employee;

public interface EmployeeService {

    Employee registerEmployee(Employee employee);

    Employee getEmployeeById(Long id);

    List<Employee> getAllEmployees();

    Employee updateEmployee(Long id, Employee employee);

    void deleteEmployee(Long id);

    Employee login(String email, String password);
}