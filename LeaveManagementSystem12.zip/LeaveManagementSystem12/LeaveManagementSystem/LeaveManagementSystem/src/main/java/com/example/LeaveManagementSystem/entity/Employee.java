package com.example.LeaveManagementSystem.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "employees")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String email;
    private String password;
    private String department;
    private String role;

    @Column(name = "total_leave_balance")
    private Integer totalLeaveBalance;

    @Column(name = "used_leaves")
    private Integer usedLeaves;

    @Column(name = "remaining_leaves")
    private Integer remainingLeaves;

    public Employee() {
    }

    public Employee(Long id, String name, String email,
                    String password, String department, String role,
                    Integer totalLeaveBalance, Integer usedLeaves, Integer remainingLeaves) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.department = department;
        this.role = role;
        this.totalLeaveBalance = totalLeaveBalance;
        this.usedLeaves = usedLeaves;
        this.remainingLeaves = remainingLeaves;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Integer getTotalLeaveBalance() {
        return totalLeaveBalance;
    }

    public void setTotalLeaveBalance(Integer totalLeaveBalance) {
        this.totalLeaveBalance = totalLeaveBalance;
    }

    public Integer getUsedLeaves() {
        return usedLeaves;
    }

    public void setUsedLeaves(Integer usedLeaves) {
        this.usedLeaves = usedLeaves;
    }

    public Integer getRemainingLeaves() {
        return remainingLeaves;
    }

    public void setRemainingLeaves(Integer remainingLeaves) {
        this.remainingLeaves = remainingLeaves;
    }
}