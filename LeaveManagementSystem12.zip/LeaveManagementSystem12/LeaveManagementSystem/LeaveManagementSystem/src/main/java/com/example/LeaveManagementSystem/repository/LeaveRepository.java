package com.example.LeaveManagementSystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.LeaveManagementSystem.entity.LeaveRequest;
import com.example.LeaveManagementSystem.entity.Employee;
import java.util.List;

public interface LeaveRepository
        extends JpaRepository<LeaveRequest, Long> {

    List<LeaveRequest> findByEmployee(Employee employee);
}