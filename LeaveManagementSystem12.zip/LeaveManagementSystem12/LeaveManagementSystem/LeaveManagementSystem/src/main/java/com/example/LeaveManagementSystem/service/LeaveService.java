package com.example.LeaveManagementSystem.service;

import java.util.List;
import com.example.LeaveManagementSystem.entity.LeaveRequest;
import com.example.LeaveManagementSystem.entity.Employee;

public interface LeaveService {

    LeaveRequest applyLeave(LeaveRequest leave);

    List<LeaveRequest> getAllLeaves();

    LeaveRequest getLeaveById(Long id);

    void deleteLeave(Long id);

    List<LeaveRequest> getLeavesByEmployee(Employee employee);
}