package com.example.LeaveManagementSystem.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.LeaveManagementSystem.entity.Employee;
import com.example.LeaveManagementSystem.entity.LeaveRequest;
import com.example.LeaveManagementSystem.repository.EmployeeRepository;
import com.example.LeaveManagementSystem.repository.LeaveRepository;
import com.example.LeaveManagementSystem.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private LeaveRepository leaveRepository;

    @Override
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    @Override
    public List<LeaveRequest> getAllLeaveRequests() {
        return leaveRepository.findAll();
    }

    @Override
    public LeaveRequest approveLeave(Long id, String managerComment) {
        LeaveRequest leave = leaveRepository.findById(id).orElse(null);

        if (leave != null && !"APPROVED".equalsIgnoreCase(leave.getStatus())) {
            leave.setStatus("APPROVED");
            leave.setManagerComment(managerComment);

            LeaveRequest savedLeave = leaveRepository.save(leave);

            Employee employee = leave.getEmployee();

            if (employee != null) {
                if (employee.getTotalLeaveBalance() == null) {
                    employee.setTotalLeaveBalance(12);
                }
                if (employee.getUsedLeaves() == null) {
                    employee.setUsedLeaves(0);
                }
                if (employee.getRemainingLeaves() == null) {
                    employee.setRemainingLeaves(employee.getTotalLeaveBalance());
                }

                int appliedDays = leave.getAppliedDays() != null ? leave.getAppliedDays() : 0;

                employee.setUsedLeaves(employee.getUsedLeaves() + appliedDays);
                employee.setRemainingLeaves(employee.getTotalLeaveBalance() - employee.getUsedLeaves());

                employeeRepository.save(employee);
            }

            return savedLeave;
        }

        return null;
    }

    @Override
    public LeaveRequest rejectLeave(Long id, String managerComment) {
        LeaveRequest leave = leaveRepository.findById(id).orElse(null);

        if (leave != null) {
            leave.setStatus("REJECTED");
            leave.setManagerComment(managerComment);
            return leaveRepository.save(leave);
        }

        return null;
    }

    @Override
    public void deleteEmployee(Long id) {
        employeeRepository.deleteById(id);
    }
}