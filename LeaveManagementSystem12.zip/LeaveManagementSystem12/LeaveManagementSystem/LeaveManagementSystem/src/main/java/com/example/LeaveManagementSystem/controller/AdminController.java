package com.example.LeaveManagementSystem.controller;

import com.example.LeaveManagementSystem.entity.Employee;
import com.example.LeaveManagementSystem.service.AdminService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    // ================= ADMIN DASHBOARD =================
    @GetMapping("/dashboard")
    public String adminDashboard(HttpSession session, Model model) {
        Employee employee = (Employee) session.getAttribute("loggedInEmployee");

        if (employee == null || !"Admin".equalsIgnoreCase(employee.getRole())) {
            return "redirect:/login";
        }

        model.addAttribute("employees", adminService.getAllEmployees());
        model.addAttribute("leaves", adminService.getAllLeaveRequests());

        return "admin-dashboard";
    }

    // ================= MANAGE EMPLOYEES =================
    @GetMapping("/employees")
    public String manageEmployees(HttpSession session, Model model) {
        Employee employee = (Employee) session.getAttribute("loggedInEmployee");

        if (employee == null || !"Admin".equalsIgnoreCase(employee.getRole())) {
            return "redirect:/login";
        }

        model.addAttribute("employees", adminService.getAllEmployees());
        return "manage-employees";
    }

    // ================= DELETE EMPLOYEE =================
    @GetMapping("/delete/{id}")
    public String deleteEmployee(@PathVariable Long id, HttpSession session) {
        Employee employee = (Employee) session.getAttribute("loggedInEmployee");

        if (employee == null || !"Admin".equalsIgnoreCase(employee.getRole())) {
            return "redirect:/login";
        }

        adminService.deleteEmployee(id);
        return "redirect:/admin/employees";
    }

    // ================= MANAGE LEAVES =================
    @GetMapping("/leaves")
    public String manageLeaves(HttpSession session, Model model) {
        Employee employee = (Employee) session.getAttribute("loggedInEmployee");

        if (employee == null || !"Admin".equalsIgnoreCase(employee.getRole())) {
            return "redirect:/login";
        }

        model.addAttribute("leaves", adminService.getAllLeaveRequests());
        return "manage-leaves";
    }

    // ================= APPROVE LEAVE =================
    @PostMapping("/approve/{id}")
    public String approveLeave(@PathVariable Long id,
                               @RequestParam(value = "managerComment", required = false) String managerComment,
                               HttpSession session) {
        Employee employee = (Employee) session.getAttribute("loggedInEmployee");

        if (employee == null || !"Admin".equalsIgnoreCase(employee.getRole())) {
            return "redirect:/login";
        }

        adminService.approveLeave(id, managerComment);
        return "redirect:/admin/leaves";
    }

    // ================= REJECT LEAVE =================
    @PostMapping("/reject/{id}")
    public String rejectLeave(@PathVariable Long id,
                              @RequestParam(value = "managerComment", required = false) String managerComment,
                              HttpSession session) {
        Employee employee = (Employee) session.getAttribute("loggedInEmployee");

        if (employee == null || !"Admin".equalsIgnoreCase(employee.getRole())) {
            return "redirect:/login";
        }

        adminService.rejectLeave(id, managerComment);
        return "redirect:/admin/leaves";
    }
}