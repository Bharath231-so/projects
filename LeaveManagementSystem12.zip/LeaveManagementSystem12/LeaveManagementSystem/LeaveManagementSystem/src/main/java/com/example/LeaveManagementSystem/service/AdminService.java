package com.example.LeaveManagementSystem.service;

import java.util.List;

import com.example.LeaveManagementSystem.entity.Employee;
import com.example.LeaveManagementSystem.entity.LeaveRequest;

public interface AdminService {

    List<Employee> getAllEmployees();

    List<LeaveRequest> getAllLeaveRequests();

    LeaveRequest approveLeave(Long id,String managerComment);

    LeaveRequest rejectLeave(Long id,String managerComment);

    void deleteEmployee(Long id);
}