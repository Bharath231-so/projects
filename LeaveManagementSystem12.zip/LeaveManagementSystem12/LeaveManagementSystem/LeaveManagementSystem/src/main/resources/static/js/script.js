// =====================
// REGISTRATION VALIDATION
// =====================
function validateRegistration() {

    let name = document.getElementsByName("name")[0].value;
    let email = document.getElementsByName("email")[0].value;
    let password = document.getElementsByName("password")[0].value;

    if(name.trim() === ""){
        alert("Please enter name");
        return false;
    }

    if(email.trim() === ""){
        alert("Please enter email");
        return false;
    }

    if(password.length < 6){
        alert("Password must be at least 6 characters");
        return false;
    }

    return true;
}

// =====================
// LEAVE FORM VALIDATION
// =====================
function validateLeaveForm() {

    let leaveType = document.getElementsByName("leaveType")[0].value;
    let startDate = document.getElementsByName("startDate")[0].value;
    let endDate = document.getElementsByName("endDate")[0].value;
    let reason = document.getElementsByName("reason")[0].value;

    if(leaveType.trim() === ""){
        alert("Please enter leave type");
        return false;
    }

    if(startDate === ""){
        alert("Please select start date");
        return false;
    }

    if(endDate === ""){
        alert("Please select end date");
        return false;
    }

    if(new Date(startDate) > new Date(endDate)){
        alert("Start date cannot be greater than end date");
        return false;
    }

    if(reason.trim() === ""){
        alert("Please enter reason");
        return false;
    }

    return true;
}

// =====================
// CONFIRM ACTIONS
// =====================
function confirmApprove(){
    return confirm("Are you sure you want to APPROVE this leave?");
}

function confirmReject(){
    return confirm("Are you sure you want to REJECT this leave?");
}

// =====================
// PAGE LOADED MESSAGE
// =====================
window.onload = function(){
    console.log("Leave Management System Loaded Successfully");
};