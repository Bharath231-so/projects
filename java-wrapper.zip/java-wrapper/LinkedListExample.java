import java.util.*;
public class LinkedListExample {
    public static void main(String[] args) {
        List<String> list = new LinkedList<>();
        list.add("A");
        list.add("B");
        list.add("T");
        list.add(2, "D");
        System.out.println(list);
        System.out.println(list.get(2));
        list.set(2, "S");
        System.out.println(list);
    }
}
