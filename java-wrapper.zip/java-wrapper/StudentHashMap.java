import java.util.*;
class Student{
    int id;
    String name;
    Student(int id,String name){
        this.id=id;
        this.name=name;
    }
}
public class StudentHashMap {
    public static void main(String[] args) {
        Map<Integer,Student> map = new HashMap<>();
        map.put(new Stude1,"Bharath"));
        map.put(new Student(2, "Ravi"));

    }
}

