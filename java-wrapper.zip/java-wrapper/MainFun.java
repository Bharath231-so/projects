interface Vehicle {
    void run();
    default void fuelType(){
        System.out.println("petrol or diesel");
    }

    static void company(){
        System.out.println("TATA");
    }
}
public class MainFun {
    public static void main(String[] args) {
        Vehicle v =() -> System.out.println("vehicle is running");
        v.run();
        v.fuelType();
        Vehicle.company();
    }
}
