interface Greeting{
    void sayHello();
    
}
public class FunctionalExample {
    public static void main(String[] args) {
        /*Greeting g = new Greeting() {
            public void sayHello(){
                System.out.println("Hello world");
            }
        };*/
        Greeting g = () ->System.out.println("Hello world");
        g.sayHello();
    }
}
