import java.util.*;
public class CountExample {
    public static void main(String[] args) {
       /* List<String>list=Arrays.asList("A","A","B","C");
        long cnt = list.stream().filter(x -> x.equals("A")).count();
        System.out.println(cnt);
*/
        List<Integer> list = Arrays.asList(1,1,2,2,3,4,5,6,7,8,9,10);
       // long sum = list.stream().reduce(1,(a,b) -> a+b );
       //list.stream().distinct().forEach(System.out::println);
        //System.out.println(sum);
        list.stream().skip(2).limit(8).forEach(System.out::println);
    }
}
