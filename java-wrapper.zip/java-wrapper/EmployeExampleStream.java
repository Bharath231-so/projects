import java.util.*;
import java.util.stream.Collectors;
class Employe{
    int id;
    String name;
    double salary;
    Employe(int id,String name, double salary){
        this.id=id;
        this.name =name;
        this.salary=salary;

    }
}

public class EmployeExampleStream {
    public static void main(String[] args) {
        List<Employe>list = Arrays.asList(new Employe(1, "Bharath", 10000), new Employe(2, "sharath", 40000), new Employe(4, "Ravi", 180000));
        List<String>highSalaryNames=list.stream().filter(emp -> emp.salary > 10000).map(emp -> emp.name).collect(Collectors.toList());
        System.out.println(highSalaryNames);
    }
}
