import java.util.*;

public class Upperbound {
    public static double sum(List<? extends Number> list) {
        double tot = 0.0;
        for(Number n : list){
            tot+=n.doubleValue();
        }
        return tot;
    }
    public static void main(String[] args){
        List<Integer>intList = Arrays.asList(10,20);
        List<Double> doubList = Arrays.asList(1.2,2.3);
        System.out.println(sum(intList));
        System.out.println(sum(doubList));
    }
}
