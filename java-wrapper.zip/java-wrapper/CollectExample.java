import java.util.*;
import java.util.stream.Collector;
import java.util.stream.Collectors;
public class CollectExample {
    public static void main(String[] args) {
        List<Integer>list = Arrays.asList(10,18,22,33,44);
        List<Integer>res=list.stream().filter(x -> x > 10).collect(Collectors.toList());
        System.out.println(res);

    }
}
