import java.util.*;
public class WithStream {
    public static void main(String[] args) {
        List<Integer> list = Arrays.asList(10,20,30,45,5,12);
        list.stream().filter(num -> num > 10).forEach(System.out::println);
    }
}
