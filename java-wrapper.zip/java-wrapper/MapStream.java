import java.util.*;
public class MapStream {
   public static void main(String[] args) {
    List<String> num = Arrays.asList("A","b","C","d","E");
    //List<Integer> num = Arrays.asList(20,40,30,50,60);
    //num.stream().map(n -> n*2).forEach(System.out::println);
    num.stream().sorted().forEach(System.out::println);
   } 
}
