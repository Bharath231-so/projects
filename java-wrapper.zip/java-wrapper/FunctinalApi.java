@FunctionalInterface

interface  Add {
    int sum(int a,int b);//parameter and return type

}

public class FunctinalApi {
    public static void main(String[] args) {
        Add add = (a,b) -> a+b;
        System.out.println(" "+add.sum(10, 40));
    }    
}
