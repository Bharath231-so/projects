import java.util.*;

public class RealTimeExample {
    public static void main(String[] args) {
        List<Integer>marks=new ArrayList<>();

        marks.add(58);
        marks.add(45);
        marks.add(69);

        int tot=0;
        for(int m:marks){
            tot+=m;
        }
        double avg = (double) tot/marks.size();
        System.out.println(" "+ avg);
    }
}
