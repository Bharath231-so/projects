import java.util.*;
public class HashSetExample {

    public static void main(String[] args) {
        Set<Integer> set = new HashSet<>();
        set.add(10);
        set.add(30);
        set.add(40);
        set.add(80);
        System.out.println(set);
    }
}
