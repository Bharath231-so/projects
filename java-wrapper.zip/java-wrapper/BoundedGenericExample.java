
class Calculator<T extends Number> {
    public double square(T num){
        return num.doubleValue()*num.doubleValue();
    }
}

public class BoundedGenericExample {
    public static void main(String[] args) {
        Calculator<Integer> calc = new Calculator<>();
        System.out.println(calc.square(5));
    }
    
}
