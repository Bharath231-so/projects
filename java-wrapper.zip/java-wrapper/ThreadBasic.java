class MyThread extends Thread{
    @Override
    public void run(){
        System.out.println("Thread is running");
    }
}
public class ThreadBasic {
    public static void main(String[] args) {
        MyThread h1=new MyThread();
        h1.start();//start the thread
    }
}
