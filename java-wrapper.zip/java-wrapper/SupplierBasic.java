import java.util.function.Supplier;
//import java.util.Random;

public class SupplierBasic {
    public static void main(String[] args) {
        Supplier<Double>  randomValue=()-> Math.random();
        System.out.println(randomValue.get());
    }    
}
