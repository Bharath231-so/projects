import java.util.*;

public class ArrayLt {
    public static void main(String[] args) {
        List<Integer>list=new ArrayList<>();
        list.add(40);
        list.add(70);
        list.add(50);
        list.add(60);
        System.out.println(list.get(3));
        list.remove(2);
        System.out.println(list);
        System.out.println(list.size());
    }
}
