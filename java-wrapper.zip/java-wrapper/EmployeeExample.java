import java.util.*;
class Employee{
    int id;
    String name;
    Employee(int id,String name){
        this.id = id;
        this.name=name;
    }
}
public class EmployeeExample {

    public static void main(String[] args) {
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee(1,"Bharath"));
        employees.add(new Employee(2,"venu"));
        for(Employee emp:employees){
            System.out.println(emp.id + " "+ emp.name);
        }
    }   
}
