import java.util.*;
public class FilterExample {
    public static void main(String[] args) {
        List<String> names = Arrays.asList("Bharath","Raj","Ravi","Kiran");
        //names.stream().filter(name -> name.startsWith("R")).forEach(System.out::println);
        names.stream().filter(name -> name.endsWith("h")).forEach(System.out::println);
    }
}
