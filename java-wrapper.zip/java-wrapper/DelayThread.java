class SleepExample extends Thread{
    public void run(){
        for(int i=1;i<=3;i++){
            try{
                Thread.sleep(2000);
            }catch(InterruptedException e){
                e.printStackTrace();
            }
            System.out.println(i);
        }
    }
}
public class DelayThread {
    public static void main(String[] args) {
        new SleepExample().start();
    }
}
