class MyRunnable  implements Runnable{
    public void run(){
        System.out.println("Runnable thread is running");
    }
}
public class MyRunnableExample {
    public static void main(String[] args) {
        MyRunnable obj = new MyRunnable();
        Thread h2 = new Thread(obj);
        h2.start();
    }
}
