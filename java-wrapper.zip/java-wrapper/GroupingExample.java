import java.util.*;
import java.util.stream.Collectors;
class Emp{
    String name ;
    String department;
    Emp(String name,String department){
        this.name=name;
        this.department=department;
    }
}
public class GroupingExample {
    public static void main(String[] args) {
        List<Emp> list = Arrays.asList(new Emp("Rahul", "IT"),new Emp("Rohit", "semi-IT"),new Emp("Venu", "HR"));

        Map<String,List<Emp>>grouped = list.stream().collect(Collectors.groupingBy(emp -> emp.department));
        System.out.println(grouped);
    }
}
