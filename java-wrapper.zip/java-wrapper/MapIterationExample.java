import java.util.*;

public class MapIterationExample {
    public static void main(String[] args) {
        Map<Integer,String> map = new HashMap<>();
        map.put(1, "Ravi");
        map.put(2, "vamshi");
        map.put(3, "Swaraj");
        System.out.println(map);
        for(Integer key:map.keySet()){
            System.out.println(key+" -> "+ map.get(key));
        }
    }    
}
