import java.util.*;
public class Basic {
    public static void main(String[] args) {
        Map<String, Integer> marks = new HashMap<>();
        marks.put("Bharath", 40);
        marks.put("ravi", 60);
        marks.put("swaraj", 58);
        for(String name : marks.keySet())
            System.out.println(name + " "+marks.get(name));
    }
}
