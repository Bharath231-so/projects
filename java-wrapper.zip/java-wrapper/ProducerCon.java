import java.util.concurrent.locks.ReentrantLock;
class Counter{
    int cnt =0;
    ReentrantLock lock = new ReentrantLock();
    void increment(){
        lock.lock();
        try{
            cnt++;
        }finally{
            lock.unlock();
        }
    }
}
public class ProducerCon {
    
}
