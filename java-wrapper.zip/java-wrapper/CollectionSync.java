import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CollectionSync {
    public static void main(String[] args) throws InterruptedException {
        List<String> list = Collections.synchronizedList(new ArrayList<>());
        Thread t1 = new Thread(() -> {
            for(int i=0;i<5;i++){
                list.add("A- " + i);
            }
        });
         Thread t2 = new Thread(() -> {
            for(int i=0;i<5;i++){
                list.add("B- " + i);
            }
        });
        t1.start();
        t2.start();
        t1.join();
        t2.join();
        System.out.println("List Size :" + list.size());
        System.out.println(list);
    }
}
