import java.util.*;
public class Main1 {
    public static void main(String[] args){
        List<Integer> list = new ArrayList<>();
        list.add(12);
        
    }
}
