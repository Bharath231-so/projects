import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main16 {
    public static void main(String[] args) {
        ExecutorService executor= Executors.newFixedThreadPool(3);
        for(int i =1;i<=5;i++){
            int taskId=i;
            executor.submit(() ->{
                System.out.println("Executing Task" + taskId + " by "+ Thread.currentThread().getName());
                try{
                    Thread.sleep(1000);
                }catch(InterruptedException e){
                    e.printStackTrace();
                }
            });
        }
        executor.shutdown();
    }

}
