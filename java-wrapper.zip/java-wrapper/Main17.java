import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Main17 {
    public static void main(String[] args) throws Exception {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Callable<Integer>task = () -> {
            Thread.sleep(2300);
            return 10+20;
        };
        Future <Integer> future=executor.submit(task);
        System.out.println("waiting for result..");
        System.out.println("Result:"+ future.get());
        executor.shutdown();
    }
}
