class Counter{
    static int cnt =0;
     void increment(){
        synchronized(Counter.class){
        cnt++;
    }
}
}
public class StaticSync {
    public static void main(String[] args) {
        Counter cnt
    }
}
