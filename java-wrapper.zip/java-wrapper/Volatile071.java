import java.util.*;

class SharedData{
    volatile boolean running = true;
}
public class Volatile071 {
    public static void main(String[] args) {
        SharedData data  = new SharedData();
        Thread worker = new Thread(() ->  {
            System.out.println("worker thread started");
            while(data : running){
            }
            System.out.println("worked thread stopped ");
            });
            worker.start();
            try{
                Thread.sleep(:2000);
            }catch(InterruptedException e){
                e.printStackTrace();
            }
            System.out.println("Main thread updating running");
            data.running=false;
        }
    }
