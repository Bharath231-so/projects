
import java.util.concurrent.ConcurrentHashMap;

public class Main07 {

    public static void main(String[] args) {

        ConcurrentHashMap<String,Integer>map= new ConcurrentHashMap<>();
        Runnable task =() -> {
            for(int j=0;j<5;j++){
                map.put(Thread.currentThread().getName()+ "-"+ j,j);
            }
        };
        Thread t1 = new Thread(task);
        Thread t2 = new Thread(task);
        t1.start();
        t2.start();
        try{
            t1.join();
            t2.join();
        }catch(InterruptedException e){
            e.printStackTrace();
        }
        System.out.println(map);
    }   
}
