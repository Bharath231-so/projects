import java.util.*;
class empl{
    int id;
    String name;
    empl(int id, String name){
        this.id=id;
        this.name=name;
    }
    public String getName(){
        return name;
    }
    public String toString(){
        return id +" "+name;
    }
}
public class Main21 {
    public static void main(String[] args) {
        List<>
    }
}
