public class WrapperClsConversion {
    public static void main(String[] args) {
        int num = 100;
        String str1 = Integer.toString(num);
        System.out.println("Integer to String "+ str1);
        String str = "200";
        int n1 = Integer.parseInt(str);
        System.out.println(" String to int "+ n1);
    }
}
