import java.util.*;
public class HashMapExample {
    public static void main(String[] args) {
        HashMap<Integer,String > map = new HashMap<>();
        map.put(1, "Bharath");
        map.put(2, "venu");
        map.put(3, "sharath");
        System.out.println(" "+ map.get(2));
        System.out.println(" "+ map.containsValue("Bharath"));
        
    }
}
