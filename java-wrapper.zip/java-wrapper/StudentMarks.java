import java.util.*;
public class StudentMarks {
public static void main(String[] args) {
    Map<String,Integer> map = new HashMap<>();
    map.put("Bharath", 78);
    map.put("tej", 62);
    map.put("raj", 65);
    int max =0;
    String Topper="";
    for(Map.Entry<String , Integer> entry:map.entrySet()){
        if(entry.getValue()>max){
        max=entry.getValue();
        Topper=entry.getKey();
        }
    }
    System.out.println("topper:" + Topper);
    System.out.println("marks: "+ max);
}
}
  
