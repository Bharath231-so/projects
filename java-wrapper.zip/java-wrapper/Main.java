public class Main{
    public static<T> void printArray(T[] array){ //t is a generic method
        for(T element: array){
            System.out.println(element);
        }
    }
    public static void main(String[] args) {
        Integer[] intArray = {1,2,3};
        String[] strArray = {"A","B","C"};
        printArray(intArray);
        printArray(strArray);
    }
}