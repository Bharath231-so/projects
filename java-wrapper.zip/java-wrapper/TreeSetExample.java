
import java.util.*;

public class TreeSetExample {
     public static void main(String[] args) {
        Set<Integer> set = new TreeSet<>();
        set.add(10);
        set.add(30);
        set.add(40);
       // set.add(null);
        set.add(80);
        System.out.println(set.size());
        System.out.println(set.isEmpty());
    }
}
