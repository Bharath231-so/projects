import java.util.*;

public class Asic {
    public static void main(String[] args) {
        List<String>list=new ArrayList<>();
        list.add("Bharath");
        list.add("rahul");
        list.add("John");
        System.out.println(list);
    }   
}
