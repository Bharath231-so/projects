import java.util.*;
public class HashSetString {
    public static void main(String[] args) {
     Set<String> set = new HashSet<>();
     set.add("java");
     set.add("python");
     System.out.println(set);   
    }
}
