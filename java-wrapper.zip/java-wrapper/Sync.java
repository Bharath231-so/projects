class shared{
    synchronized void print(){
        System.out.println("waiting...");
        try{
            wait();
        }catch(InterruptedException e){
        }
        System.out.println("Resumed!.");
    }
    synchronized void notifyThread(){
        notify();
    }
}
public class Sync {
 public static void main(String[] args) {
    shared obj=new shared();
    Thread t1=new Thread(() -> { obj.print();
    });
    Thread t2=new Thread(() -> {
        try{
            Thread.sleep(2000);

        }catch(Exception e ){}
        obj.notifyThread();
    });
    t1.start();
    t2.start();
 }   
}
