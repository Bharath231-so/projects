package com.example.springboot_jdbc_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootJdbcDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootJdbcDemoApplication.class, args);
	}

}
