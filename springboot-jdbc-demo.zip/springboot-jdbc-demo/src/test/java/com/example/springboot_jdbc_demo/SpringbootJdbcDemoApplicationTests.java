package com.example.springboot_jdbc_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootJdbcDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
